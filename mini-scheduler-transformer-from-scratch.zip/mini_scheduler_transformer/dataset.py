import json,torch
from torch.utils.data import Dataset
class DS(Dataset):
 def __init__(self,p,tok,maxlen): self.a=[json.loads(x) for x in open(p)]; self.t=tok; self.m=maxlen
 def __len__(self): return len(self.a)
 def __getitem__(self,i):
  z=self.a[i]; ids=self.t.encode(z['user'],z['assistant'])[:self.m]; x=torch.tensor(ids[:-1]); y=torch.tensor(ids[1:]); marker=len(self.t.encode(z['user'],''))-1; y[:min(marker,len(y))]=-100; return x,y
def collate(batch,pad):
 m=max(len(x) for x,y in batch); xs=[];ys=[]
 for x,y in batch:
  n=m-len(x); xs.append(torch.cat([x,torch.full((n,),pad,dtype=torch.long)])); ys.append(torch.cat([y,torch.full((n,),-100,dtype=torch.long)]))
 return torch.stack(xs),torch.stack(ys)
