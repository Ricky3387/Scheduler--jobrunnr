import argparse,torch
from config import Config
from tokenizer import CharTokenizer
from model import MiniTransformer
p=argparse.ArgumentParser();p.add_argument('prompt');a=p.parse_args();dev='cuda' if torch.cuda.is_available() else 'cpu'; ck=torch.load('checkpoints/scheduler_transformer.pt',map_location=dev); c=Config(); c.__dict__.update(ck['config']); tok=CharTokenizer.load('checkpoints/tokenizer.json'); m=MiniTransformer(c,ck['vocab_size']).to(dev);m.load_state_dict(ck['model']);m.eval();x=torch.tensor([tok.encode(a.prompt)],device=dev);print(tok.decode(m.generate(x,tok.eos_id)[0].tolist()))
