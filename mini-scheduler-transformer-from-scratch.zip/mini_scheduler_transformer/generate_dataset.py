import json,random
from pathlib import Path
REPORTS=['SALES_REPORT','CUSTOMER_REPORT','FINANCE_REPORT','INVENTORY_REPORT']; FORMATS=['PDF','CSV','EXCEL']; DAYS=['MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY']; TIMES=['08:00','09:00','10:00','12:00','15:00','18:00']; POLICIES=['SKIP','PREVIOUS_BUSINESS_DAY','NEXT_BUSINESS_DAY']
def rec(u,a): return {'user':u,'assistant':json.dumps(a,separators=(',',':'))}
def make():
 r=random.choice(REPORTS); d=random.choice(DAYS); t=random.choice(TIMES); f=random.choice(FORMATS); p=random.choice(POLICIES)
 opts=[rec(f'Run the {r} every {d.title()} at {t}.',{'intent':'CREATE_SCHEDULE','reportType':r,'schedule':{'frequency':'WEEKLY','interval':1,'daysOfWeek':[d],'startTime':t,'timezone':'Asia/Kolkata','holidayPolicy':'SKIP'}}),rec(f'Run {r} every day at {t}.',{'intent':'CREATE_SCHEDULE','reportType':r,'schedule':{'frequency':'DAILY','interval':1,'startTime':t,'timezone':'Asia/Kolkata','holidayPolicy':'SKIP'}}),rec(f'Generate the {r} for July in {f}.',{'intent':'RUN_REPORT','reportType':r,'format':f,'parameters':{'month':'2026-07'}}),rec(f'Run the {r} now as {f}.',{'intent':'RUN_REPORT','reportType':r,'format':f,'parameters':{}}),rec(f'Show my latest {r}.',{'intent':'LIST_REPORTS','reportType':r}),rec(f'Download the latest {r}.',{'intent':'DOWNLOAD_REPORT','reportType':r,'latest':True}),rec(f'Run {r} every Friday at {t}; if Friday is a holiday, move it to the previous business day.',{'intent':'CREATE_SCHEDULE','reportType':r,'schedule':{'frequency':'WEEKLY','interval':1,'daysOfWeek':['FRIDAY'],'startTime':t,'timezone':'Asia/Kolkata','holidayPolicy':'PREVIOUS_BUSINESS_DAY'})}]
 return random.choice(opts)
def write(path,n):
 path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('w') as f:
  for _ in range(n): f.write(json.dumps(make())+'\n')
if __name__=='__main__': random.seed(42); write(Path('data/train.jsonl'),12000); write(Path('data/validation.jsonl'),1500); print('dataset generated')
