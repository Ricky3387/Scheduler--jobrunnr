# Mini Scheduler Transformer

A small decoder-only Transformer built from scratch in PyTorch. No Qwen, Hugging Face, or pretrained model.

It learns your narrow domain: natural language -> structured scheduler/report intent.

## Run

```bash
pip install -r requirements.txt
python generate_dataset.py
python train.py
python infer.py "Run sales report every Monday at 9 AM"
```

Default model is intentionally small (~5M parameters): 6 Transformer blocks, d_model 256, 8 heads.

The model is only responsible for interpreting language. Spring Boot must validate and execute the resulting intent; never let model output execute code, SQL, Quartz configuration, or storage operations.

To move toward 50M/100M parameters, increase d_model, layers, feed-forward dimension and train on a much larger dataset. For a serious model, replace the character tokenizer with BPE/SentencePiece.
