from dataclasses import dataclass
@dataclass
class Config:
    d_model:int=256; n_heads:int=8; n_layers:int=6; d_ff:int=1024; max_seq_len:int=512; dropout:float=.1
    batch_size:int=32; epochs:int=15; learning_rate:float=3e-4; weight_decay:float=.01
    train_file:str='data/train.jsonl'; val_file:str='data/validation.jsonl'; checkpoint:str='checkpoints/scheduler_transformer.pt'
