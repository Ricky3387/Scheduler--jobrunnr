import math,torch
import torch.nn as nn
import torch.nn.functional as F
class Attention(nn.Module):
 def __init__(self,cfg):
  super().__init__(); assert cfg.d_model%cfg.n_heads==0; self.h=cfg.n_heads; self.d=cfg.d_model//cfg.n_heads; self.qkv=nn.Linear(cfg.d_model,3*cfg.d_model); self.proj=nn.Linear(cfg.d_model,cfg.d_model); self.drop=nn.Dropout(cfg.dropout); self.register_buffer('mask',torch.tril(torch.ones(cfg.max_seq_len,cfg.max_seq_len))[None,None])
 def forward(self,x):
  B,T,C=x.shape; q,k,v=self.qkv(x).split(C,2); q=q.view(B,T,self.h,self.d).transpose(1,2); k=k.view(B,T,self.h,self.d).transpose(1,2); v=v.view(B,T,self.h,self.d).transpose(1,2); s=(q@k.transpose(-2,-1))/math.sqrt(self.d); s=s.masked_fill(self.mask[:,:,:T,:T]==0,float('-inf')); a=F.softmax(s,-1); return self.proj((self.drop(a)@v).transpose(1,2).contiguous().view(B,T,C))
class Block(nn.Module):
 def __init__(self,c):
  super().__init__(); self.a=Attention(c); self.l1=nn.LayerNorm(c.d_model); self.l2=nn.LayerNorm(c.d_model); self.ff=nn.Sequential(nn.Linear(c.d_model,c.d_ff),nn.GELU(),nn.Linear(c.d_ff,c.d_model),nn.Dropout(c.dropout))
 def forward(self,x): x=x+self.a(self.l1(x)); return x+self.ff(self.l2(x))
class MiniTransformer(nn.Module):
 def __init__(self,cfg,vocab):
  super().__init__(); self.cfg=cfg; self.e=nn.Embedding(vocab,cfg.d_model); self.p=nn.Embedding(cfg.max_seq_len,cfg.d_model); self.blocks=nn.Sequential(*[Block(cfg) for _ in range(cfg.n_layers)]); self.ln=nn.LayerNorm(cfg.d_model); self.head=nn.Linear(cfg.d_model,vocab,bias=False)
 def forward(self,idx,targets=None):
  B,T=idx.shape; x=self.e(idx)+self.p(torch.arange(T,device=idx.device))[None]; x=self.blocks(x); logits=self.head(self.ln(x)); loss=None if targets is None else F.cross_entropy(logits.reshape(-1,logits.size(-1)),targets.reshape(-1),ignore_index=-100); return logits,loss
 @torch.no_grad()
 def generate(self,idx,eos,max_new=400):
  for _ in range(max_new):
   logits,_=self(idx[:,-self.cfg.max_seq_len:]); n=logits[:,-1].argmax(-1,keepdim=True); idx=torch.cat([idx,n],1)
   if int(n[0])==eos: break
  return idx
