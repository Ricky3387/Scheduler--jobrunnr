import json
SPECIAL=['<PAD>','<BOS>','<EOS>','<USER>','<ASSISTANT>']
class CharTokenizer:
 def train(self,texts): self.itos=SPECIAL+sorted(set(''.join(texts))); self.stoi={s:i for i,s in enumerate(self.itos)}
 @property
 def pad_id(self): return self.stoi['<PAD>']
 @property
 def bos_id(self): return self.stoi['<BOS>']
 @property
 def eos_id(self): return self.stoi['<EOS>']
 def encode(self,user,assistant=None):
  text='<BOS><USER>'+user+('' if assistant is None else '<ASSISTANT>'+assistant+'<EOS>')
  return [self.stoi[c] for c in text]
 def decode(self,ids): return ''.join(self.itos[int(i)] for i in ids if self.itos[int(i)] not in SPECIAL)
 def save(self,p): open(p,'w').write(json.dumps({'itos':self.itos}))
 @classmethod
 def load(cls,p):
  x=cls(); x.itos=json.load(open(p))['itos']; x.stoi={s:i for i,s in enumerate(x.itos)}; return x
