# Integration

React -> Spring Boot Assistant -> Mini Scheduler Transformer -> structured intent

CREATE_SCHEDULE -> ScheduleSpec -> validation -> Quartz
RUN_REPORT -> ReportManager
LIST_REPORTS -> ReportManager
DOWNLOAD_REPORT -> authorization -> GCS signed URL

The Transformer is an interpreter, not an executor.
