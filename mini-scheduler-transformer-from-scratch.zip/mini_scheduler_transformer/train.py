import json,os,torch
from torch.utils.data import DataLoader
from config import Config
from tokenizer import CharTokenizer
from dataset import DS,collate
from model import MiniTransformer
c=Config(); dev='cuda' if torch.cuda.is_available() else 'cpu'
train=[json.loads(x) for x in open(c.train_file)]; tok=CharTokenizer(); tok.train([x['user']+x['assistant'] for x in train]); os.makedirs('checkpoints',exist_ok=True); tok.save('checkpoints/tokenizer.json')
tr=DS(c.train_file,tok,c.max_seq_len); va=DS(c.val_file,tok,c.max_seq_len); dl=DataLoader(tr,batch_size=c.batch_size,shuffle=True,collate_fn=lambda b:collate(b,tok.pad_id)); vd=DataLoader(va,batch_size=c.batch_size,collate_fn=lambda b:collate(b,tok.pad_id)); model=MiniTransformer(c,len(tok.itos)).to(dev); opt=torch.optim.AdamW(model.parameters(),lr=c.learning_rate,weight_decay=c.weight_decay); print('device',dev,'parameters',sum(p.numel() for p in model.parameters()))
for ep in range(c.epochs):
 model.train(); total=0
 for x,y in dl:
  x=x.to(dev);y=y.to(dev);_,loss=model(x,y);opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1);opt.step();total+=float(loss)
 model.eval();v=0;n=0
 with torch.no_grad():
  for x,y in vd: _,l=model(x.to(dev),y.to(dev));v+=float(l);n+=1
 print('epoch',ep+1,'train',total/len(dl),'val',v/n)
 torch.save({'model':model.state_dict(),'config':c.__dict__,'vocab_size':len(tok.itos)},c.checkpoint)
