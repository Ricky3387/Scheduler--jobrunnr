# Scheduler + Report Manager Training Dataset

A domain-specific JSONL dataset for the internal scheduler AI.

- train.jsonl: 12,000 examples
- validation.jsonl: 1,500 examples
- test.jsonl: 1,500 examples

Each record:
{"user":"natural language request","assistant":"canonical JSON"}

Use the model only for natural-language interpretation. Keep authorization,
Quartz execution, holiday calculations, GCS access, and Report Manager
operations deterministic in Spring Boot.
