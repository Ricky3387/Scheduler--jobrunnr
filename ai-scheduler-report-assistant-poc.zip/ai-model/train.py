import os
from datasets import load_dataset
from transformers import AutoTokenizer,AutoModelForCausalLM,TrainingArguments
from peft import LoraConfig
from trl import SFTTrainer

MODEL_NAME=os.getenv("MODEL_NAME","Qwen/Qwen2.5-0.5B-Instruct")

ds=load_dataset("json",data_files={
    "train":"data/train.jsonl",
    "validation":"data/validation.jsonl"
})

tokenizer=AutoTokenizer.from_pretrained(MODEL_NAME)
model=AutoModelForCausalLM.from_pretrained(MODEL_NAME)

if tokenizer.pad_token is None:
    tokenizer.pad_token=tokenizer.eos_token

def format_example(e):
    return (
        "<|im_start|>system\n"+e["instruction"]+
        "<|im_end|>\n<|im_start|>user\n"+e["input"]+
        "<|im_end|>\n<|im_start|>assistant\n"+
        json_string(e["output"])+"<|im_end|>"
    )

import json
def json_string(x):
    return json.dumps(x,separators=(",",":"))

lora=LoraConfig(
    r=16,lora_alpha=32,lora_dropout=.05,bias="none",
    task_type="CAUSAL_LM",
    target_modules=["q_proj","k_proj","v_proj","o_proj"]
)

args=TrainingArguments(
    output_dir="./assistant-model",
    num_train_epochs=2,
    per_device_train_batch_size=4,
    gradient_accumulation_steps=8,
    learning_rate=2e-4,
    logging_steps=20,
    save_steps=500,
    report_to="none",
)

trainer=SFTTrainer(
    model=model,
    train_dataset=ds["train"],
    eval_dataset=ds["validation"],
    peft_config=lora,
    args=args,
    formatting_func=format_example
)

trainer.train()
trainer.save_model("./assistant-model")
tokenizer.save_pretrained("./assistant-model")
