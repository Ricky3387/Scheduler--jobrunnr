import json, random
from pathlib import Path

REPORTS=["SALES_REPORT","CUSTOMER_REPORT","FINANCE_REPORT","REGULATORY_REPORT"]
FORMATS=["PDF","CSV","EXCEL"]

def record(inp,out):
    return {
        "instruction":"Convert the request into the allowed internal assistant JSON. Return JSON only.",
        "input":inp,
        "output":out
    }

def make():
    report=random.choice(REPORTS)
    fmt=random.choice(FORMATS)
    examples=[
        (f"Generate the {report} for July in {fmt}.",
         {"intent":"RUN_REPORT","reportType":report,"format":fmt,
          "parameters":{"month":"2026-07"}}),
        (f"Run the {report} now as {fmt}.",
         {"intent":"RUN_REPORT","reportType":report,"format":fmt,"parameters":{}}),
        (f"Show my latest {report}.",
         {"intent":"LIST_REPORTS","reportType":report}),
        (f"Download the latest {report}.",
         {"intent":"DOWNLOAD_REPORT","reportType":report,"latest":True}),
        (f"Run {report} every Monday at 9 AM.",
         {"intent":"CREATE_SCHEDULE","reportType":report,
          "schedule":{"frequency":"WEEKLY","interval":1,
                      "daysOfWeek":["MONDAY"],"startTime":"09:00",
                      "timezone":"Asia/Kolkata","holidayPolicy":"SKIP"}})
    ]
    inp,out=random.choice(examples)
    return record(inp,out)

def write(path,count):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open("w",encoding="utf-8") as f:
        for _ in range(count):
            f.write(json.dumps(make())+"\n")

if __name__=="__main__":
    random.seed(42)
    write(Path("data/train.jsonl"),10000)
    write(Path("data/validation.jsonl"),1000)
    print("Dataset generated.")
