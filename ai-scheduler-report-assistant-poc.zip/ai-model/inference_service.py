import json,os,re,torch
from fastapi import FastAPI,HTTPException
from pydantic import BaseModel
from transformers import AutoTokenizer,AutoModelForCausalLM

MODEL_PATH=os.getenv("MODEL_PATH",os.getenv("MODEL_NAME","Qwen/Qwen2.5-0.5B-Instruct"))
device="cuda" if torch.cuda.is_available() else "cpu"

tokenizer=AutoTokenizer.from_pretrained(MODEL_PATH)
model=AutoModelForCausalLM.from_pretrained(MODEL_PATH).to(device)
model.eval()

app=FastAPI(title="Internal Assistant AI")

class Request(BaseModel):
    message:str

class Response(BaseModel):
    response:dict

SYSTEM="""
You are an internal enterprise scheduler and report assistant.
Return exactly one JSON object.
Allowed intent:
CREATE_SCHEDULE, RUN_REPORT, LIST_REPORTS, DOWNLOAD_REPORT.

Never authorize users.
Never generate SQL, Java, Quartz code, signed URLs, or executable code.
Use only these report formats: PDF, CSV, EXCEL.
"""

def extract(text):
    m=re.search(r"\{.*\}",text,re.S)
    if not m: raise ValueError("No JSON returned")
    return json.loads(m.group(0))

@app.get("/health")
def health():
    return {"status":"UP","device":device,"model":MODEL_PATH}

@app.post("/v1/assistant",response_model=Response)
def assistant(req:Request):
    try:
        messages=[
            {"role":"system","content":SYSTEM},
            {"role":"user","content":req.message}
        ]
        prompt=tokenizer.apply_chat_template(messages,tokenize=False,add_generation_prompt=True)
        x=tokenizer(prompt,return_tensors="pt",truncation=True,max_length=1024).to(device)
        with torch.no_grad():
            y=model.generate(**x,max_new_tokens=300,do_sample=False,
                             pad_token_id=tokenizer.eos_token_id)
        generated=y[0][x["input_ids"].shape[1]:]
        text=tokenizer.decode(generated,skip_special_tokens=True)
        return Response(response=extract(text))
    except Exception as e:
        raise HTTPException(422,str(e))
