package com.example.assistant.report;

import com.example.assistant.model.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ReportService {

    private final ReportManagerClient reportManager;

    public ReportExecution run(ReportRequest request) {
        validate(request);
        return reportManager.runReport(request);
    }

    public List<ReportExecution> list(String reportType) {
        return reportManager.listReports(reportType);
    }

    public ReportExecution latest(String reportType) {
        return reportManager.latest(reportType);
    }

    private void validate(ReportRequest request) {
        if(request.reportType()==null || request.reportType().isBlank())
            throw new IllegalArgumentException("reportType is required");

        if(request.format()==null ||
                !List.of("PDF","CSV","EXCEL").contains(request.format()))
            throw new IllegalArgumentException("format must be PDF, CSV or EXCEL");
    }
}
