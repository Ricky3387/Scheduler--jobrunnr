package com.example.assistant.ai;
import com.example.assistant.model.AssistantIntent;
public interface AiClient {
    AssistantIntent interpret(String message);
}
