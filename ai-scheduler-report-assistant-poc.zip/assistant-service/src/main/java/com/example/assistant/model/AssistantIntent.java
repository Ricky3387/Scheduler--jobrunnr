package com.example.assistant.model;

import java.util.Map;

public record AssistantIntent(
        Intent intent,
        String reportType,
        String format,
        Map<String,Object> parameters,
        Map<String,Object> schedule,
        Boolean latest
) {}
