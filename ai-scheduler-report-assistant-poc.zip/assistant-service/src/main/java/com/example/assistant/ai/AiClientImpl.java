package com.example.assistant.ai;

import com.example.assistant.model.AssistantIntent;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.Map;

@Service
public class AiClientImpl implements AiClient {
    private final RestClient client;

    public AiClientImpl(@Value("${ai.base-url}") String baseUrl) {
        client=RestClient.builder().baseUrl(baseUrl).build();
    }

    @Override
    public AssistantIntent interpret(String message) {
        Map<?,?> response=client.post()
                .uri("/v1/assistant")
                .body(Map.of("message",message))
                .retrieve().body(Map.class);

        if(response==null || response.get("response")==null)
            throw new IllegalStateException("Empty AI response");

        return new com.fasterxml.jackson.databind.ObjectMapper()
                .convertValue(response.get("response"),AssistantIntent.class);
    }
}
