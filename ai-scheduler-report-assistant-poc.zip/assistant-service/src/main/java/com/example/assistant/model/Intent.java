package com.example.assistant.model;
public enum Intent {
    CREATE_SCHEDULE, RUN_REPORT, LIST_REPORTS, DOWNLOAD_REPORT
}
