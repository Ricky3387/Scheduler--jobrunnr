package com.example.assistant.model;
import java.time.Instant;
public record ReportExecution(
        String executionId,
        String reportType,
        String format,
        String status,
        Instant createdAt,
        String downloadUrl
) {}
