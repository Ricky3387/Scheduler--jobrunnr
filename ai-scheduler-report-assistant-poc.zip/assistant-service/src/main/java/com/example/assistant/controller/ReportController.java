package com.example.assistant.controller;

import com.example.assistant.model.*;
import com.example.assistant.report.ReportService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reports")
@RequiredArgsConstructor
public class ReportController {

    private final ReportService service;

    @PostMapping("/run")
    public ReportExecution run(@RequestBody ReportRequest request) {
        return service.run(request);
    }

    @GetMapping
    public List<ReportExecution> list(
            @RequestParam(required=false) String reportType) {
        return service.list(reportType);
    }

    @GetMapping("/download/latest")
    public ReportExecution downloadLatest(
            @RequestParam String reportType) {
        ReportExecution latest=service.latest(reportType);
        if(latest==null)
            throw new IllegalArgumentException("No report found");
        return latest;
    }
}
