package com.example.assistant.model;
import jakarta.validation.constraints.NotBlank;
public record AssistantRequest(@NotBlank String message) {}
