package com.example.assistant.report;

import com.example.assistant.model.ReportExecution;
import com.example.assistant.model.ReportRequest;
import java.util.List;

public interface ReportManagerClient {
    ReportExecution runReport(ReportRequest request);
    List<ReportExecution> listReports(String reportType);
    ReportExecution latest(String reportType);
}
