package com.example.assistant.model;
import java.util.Map;
public record ReportRequest(
        String reportType,
        String format,
        Map<String,Object> parameters
) {}
