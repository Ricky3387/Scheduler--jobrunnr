package com.example.assistant.report;

import com.example.assistant.model.ReportExecution;
import com.example.assistant.model.ReportRequest;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class MockReportManagerClient implements ReportManagerClient {

    private final Map<String,ReportExecution> executions =
            new ConcurrentHashMap<>();

    @Override
    public ReportExecution runReport(ReportRequest request) {
        String id=UUID.randomUUID().toString();
        ReportExecution execution=new ReportExecution(
                id,
                request.reportType(),
                request.format(),
                "COMPLETED",
                Instant.now(),
                "https://example.internal/download/"+id
        );
        executions.put(id,execution);
        return execution;
    }

    @Override
    public List<ReportExecution> listReports(String reportType) {
        return executions.values().stream()
                .filter(x -> reportType==null ||
                        x.reportType().equals(reportType))
                .sorted(Comparator.comparing(ReportExecution::createdAt).reversed())
                .toList();
    }

    @Override
    public ReportExecution latest(String reportType) {
        return listReports(reportType).stream()
                .findFirst()
                .orElse(null);
    }
}
