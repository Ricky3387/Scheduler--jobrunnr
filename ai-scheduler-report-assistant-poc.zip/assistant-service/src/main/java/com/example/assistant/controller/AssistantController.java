package com.example.assistant.controller;

import com.example.assistant.ai.AiClient;
import com.example.assistant.model.*;
import com.example.assistant.report.ReportService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/assistant")
@RequiredArgsConstructor
public class AssistantController {

    private final AiClient ai;
    private final ReportService reports;

    @PostMapping
    public Object handle(@Valid @RequestBody AssistantRequest request) {

        AssistantIntent intent=ai.interpret(request.message());

        return switch(intent.intent()) {

            case RUN_REPORT -> reports.run(
                    new ReportRequest(
                            intent.reportType(),
                            intent.format(),
                            intent.parameters()
                    )
            );

            case LIST_REPORTS ->
                    reports.list(intent.reportType());

            case DOWNLOAD_REPORT -> {
                if(!Boolean.TRUE.equals(intent.latest()))
                    throw new IllegalArgumentException(
                            "POC supports latest=true for download");
                yield reports.latest(intent.reportType());
            }

            case CREATE_SCHEDULE ->
                    Map.of(
                            "intent","CREATE_SCHEDULE",
                            "message",
                            "Pass schedule object to the existing Scheduler/Quartz service",
                            "reportType",intent.reportType(),
                            "schedule",intent.schedule()
                    );
        };
    }
}
