# AI Scheduler + Report Assistant POC

This POC extends the scheduler AI into an internal assistant architecture.

Supported intents:
- CREATE_SCHEDULE
- RUN_REPORT
- LIST_REPORTS
- DOWNLOAD_REPORT

Architecture:

React
 -> Spring Boot AI Assistant
 -> Local Python LLM service
 -> structured intent
 -> deterministic Java validation/business logic
 -> Quartz / Report Manager

The model never decides authorization and never generates Quartz code or file URLs.

## Components

### ai-model
- synthetic dataset generation
- LoRA fine-tuning
- local FastAPI inference
- 0.5B Qwen default

### assistant-service
- Spring Boot 3 / Java 17
- AI client
- intent models
- schedule validation
- Quartz
- Report Manager client
- mock Report Manager implementation
- download URL abstraction

## Run

### AI service

```bash
cd ai-model
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python generate_dataset.py
python inference_service.py
```

Default model:
Qwen/Qwen2.5-0.5B-Instruct

### Java service

```bash
cd assistant-service
mvn spring-boot:run
```

### Test AI assistant

```bash
curl -X POST http://localhost:8080/api/assistant \
  -H "Content-Type: application/json" \
  -d '{"message":"Generate the sales report for July in Excel"}'
```

### Run report directly

```bash
curl -X POST http://localhost:8080/api/reports/run \
  -H "Content-Type: application/json" \
  -d '{"reportType":"SALES_REPORT","format":"EXCEL","parameters":{"month":"2026-07"}}'
```

### List reports

```bash
curl http://localhost:8080/api/reports
```

### Download latest report

```bash
curl "http://localhost:8080/api/reports/download/latest?reportType=SALES_REPORT"
```

The POC returns a mock signed URL. Replace `MockReportManagerClient` with your real Report Manager integration.

## Production direction

Recommended flow:

React -> OAuth/OIDC -> Assistant API -> authorization -> intent handling

For DOWNLOAD_REPORT:
1. authenticate user
2. authorize report access
3. query Report Manager/execution history
4. get GCS object
5. generate a short-lived signed URL
6. return URL to React

Do not let the LLM:
- authorize users
- generate SQL
- access GCS directly
- create Quartz triggers
- construct executable code

The LLM should only translate natural language into a constrained intent contract.
