#!/usr/bin/env bash

echo "RUN REPORT"
curl -X POST http://localhost:8080/api/assistant \
-H "Content-Type: application/json" \
-d '{"message":"Generate the sales report for July in Excel"}'

echo
echo "LIST REPORTS"
curl http://localhost:8080/api/assistant

echo
echo "DOWNLOAD LATEST"
curl -X POST http://localhost:8080/api/assistant \
-H "Content-Type: application/json" \
-d '{"message":"Download the latest sales report"}'
